# 📖 دليل النشر على GitHub - خطوة بخطوة

## 🎯 المتطلبات الأولية

قبل البدء، تأكد من:
- ✅ لديك حساب على GitHub
- ✅ Git مثبت على جهازك
- ✅ Node.js مثبت (الإصدار 16 أو أحدث)

---

## 📁 الخطوة 1: تحميل ملفات المشروع

1. **حمّل جميع الملفات** من Claude إلى مجلد على جهازك
2. **سمّي المجلد**: `genai-lecture-platform`

### 📂 هيكل الملفات المطلوب:

```
genai-lecture-platform/
├── .github/
│   └── workflows/
│       └── deploy.yml
├── src/
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
├── .gitignore
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
└── README.md
```

---

## 📝 الخطوة 2: إنشاء مستودع على GitHub

1. **اذهب إلى GitHub**: [https://github.com](https://github.com)
2. **اضغط على زر "+"** في الأعلى
3. **اختر "New repository"**
4. **املأ البيانات**:
   - Repository name: `genai-lecture-platform`
   - Description: `منصة تفاعلية لتقييم محاضرة الذكاء الاصطناعي التوليدي`
   - اختر: **Public** (عام)
   - ❌ **لا تختر** "Add a README file"
5. **اضغط "Create repository"**

---

## 💻 الخطوة 3: رفع المشروع إلى GitHub

### افتح Terminal/CMD في مجلد المشروع ثم:

```bash
# 1. التأكد من أنك في مجلد المشروع
cd genai-lecture-platform

# 2. تهيئة Git
git init

# 3. إضافة جميع الملفات
git add .

# 4. عمل Commit أولي
git commit -m "Initial commit: GenAI Lecture Platform"

# 5. ربط المستودع المحلي بـ GitHub
# استبدل YOUR_USERNAME باسم المستخدم الخاص بك
git remote add origin https://github.com/YOUR_USERNAME/genai-lecture-platform.git

# 6. تغيير اسم الفرع إلى main
git branch -M main

# 7. رفع الملفات إلى GitHub
git push -u origin main
```

### 🔐 ملاحظة: المصادقة

عند تنفيذ `git push`، سيُطلب منك:
- **Username**: اسم المستخدم في GitHub
- **Password**: استخدم **Personal Access Token** (وليس كلمة المرور)

#### كيفية إنشاء Token:
1. GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
2. Generate new token → اختر "repo" → Generate
3. انسخ الـ Token واستخدمه كـ Password

---

## ⚙️ الخطوة 4: تفعيل GitHub Pages

1. **اذهب إلى المستودع** على GitHub
2. **Settings** (الإعدادات)
3. **Pages** (من القائمة الجانبية)
4. **Source**: اختر **GitHub Actions**
5. **احفظ التغييرات**

---

## 🚀 الخطوة 5: تثبيت المكتبات وبناء المشروع

في Terminal:

```bash
# 1. تثبيت جميع المكتبات المطلوبة
npm install

# 2. اختبار المشروع محلياً (اختياري)
npm run dev
# افتح http://localhost:5173 في المتصفح

# 3. بناء المشروع للنشر
npm run build
```

---

## 📤 الخطوة 6: النشر التلقائي

بمجرد رفع الملفات إلى GitHub، سيتم النشر تلقائياً!

### كيف؟
- ملف `.github/workflows/deploy.yml` يقوم بالنشر تلقائياً عند كل Push

### تتبع عملية النشر:
1. اذهب إلى المستودع على GitHub
2. تبويب **Actions**
3. ستجد workflow يعمل
4. انتظر حتى ينتهي (✅ علامة خضراء)

---

## 🌐 الخطوة 7: الوصول إلى الموقع

بعد نجاح النشر:

**رابط الموقع**: 
```
https://YOUR_USERNAME.github.io/genai-lecture-platform/
```

استبدل `YOUR_USERNAME` باسم المستخدم الخاص بك.

---

## 🔧 الخطوة 8: تحديث المشروع (في المستقبل)

عند إجراء تعديلات:

```bash
# 1. إضافة التغييرات
git add .

# 2. عمل Commit
git commit -m "وصف التعديل"

# 3. رفع إلى GitHub
git push

# سيتم النشر تلقائياً!
```

---

## ⚠️ حل المشاكل الشائعة

### المشكلة 1: "npm: command not found"
**الحل**: قم بتثبيت Node.js من [nodejs.org](https://nodejs.org)

### المشكلة 2: "git: command not found"
**الحل**: قم بتثبيت Git من [git-scm.com](https://git-scm.com)

### المشكلة 3: الموقع لا يعمل (404)
**الحل**: 
1. تأكد من تفعيل GitHub Pages
2. تأكد من اسم المستودع صحيح
3. انتظر 2-3 دقائق بعد النشر

### المشكلة 4: الصفحة بيضاء
**الحل**: 
1. تأكد من ملف `vite.config.js` يحتوي على:
   ```js
   base: '/genai-lecture-platform/',
   ```
2. تأكد من اسم المستودع مطابق للاسم في `base`

### المشكلة 5: "Permission denied"
**الحل**: استخدم Personal Access Token بدلاً من Password

---

## 📞 الدعم

إذا واجهت أي مشكلة:
1. راجع قسم "حل المشاكل" أعلاه
2. افتح Issue في المستودع
3. تحقق من Actions Tab للأخطاء

---

## ✅ قائمة التحقق النهائية

- [ ] جميع الملفات موجودة في المجلد
- [ ] مستودع GitHub تم إنشاؤه
- [ ] الملفات تم رفعها بنجاح
- [ ] GitHub Pages مفعّل
- [ ] npm install تم تنفيذه
- [ ] Actions workflow نجح
- [ ] الموقع يعمل على الرابط

---

## 🎉 تهانينا!

الآن موقعك مباشر على الإنترنت! 🚀

شارك الرابط مع من تريد:
```
https://YOUR_USERNAME.github.io/genai-lecture-platform/
```
